// KUKU Design System — Social photo frames (1080×1080 / 1920×1080)
// Five named frames. Each enforces: 64px text-safe inset, 128px masthead reserve,
// 112px footer reserve, face-safe crops, length-aware titles, one ornament BR, no price.
import React from "react";
import { logos, ornaments, pickOrnament } from "./assets.js";

const h = React.createElement;
const J = "#17482D", JD = "#0F3220", M = "#E9AB0F", G = "#CD5647", C = "#F7F1EA", W = "#FFFFFF";
const BODY = '"Ygro Sans","Inter","Manrope",system-ui,sans-serif';
const DISPLAY = '"Dela Gothic One","Ygro Sans",system-ui,sans-serif';
const SAFE = 64, MASTHEAD = 128, FOOTER = 112;

export function titleLen(s) {
  const w = String(s || "").trim().split(/\s+/).filter(Boolean).length;
  return w <= 4 ? "short" : w <= 7 ? "medium" : "long";
}
const TITLE_PX = { short: 72, medium: 56, long: 40 };
const TITLE_LH = { short: 0.98, medium: 1.02, long: 1.08 };

const GROUND = {
  cream:   { bg: C, fg: J, wm: "jade",  stamp: M },
  jade:    { bg: J, fg: C, wm: "white", stamp: M },
  mustard: { bg: M, fg: J, wm: "jade",  stamp: J },
};
const OBJ_POS = { portrait: "center 28%", food: "center 50%", scene: "center 50%" };

const frameBase = (w, hgt, bg, fg) => ({
  position: "relative", width: w, height: hgt, boxSizing: "border-box", overflow: "hidden",
  fontFamily: BODY, color: fg, background: bg,
});
const img = (src, kind) => h("img", { src, alt: "", style: { width: "100%", height: "100%", objectFit: "cover", objectPosition: OBJ_POS[kind] || OBJ_POS.scene, display: "block" } });
const wordmark = (tone, size, style) => h("img", {
  src: tone === "white" ? logos.wordmarkHorizontalWhite : logos.wordmarkHorizontalJade,
  alt: "KUKU", style: { height: size, width: "auto", display: "block", ...style },
});
const stackedWordmark = (tone, size, style) => h("img", {
  src: tone === "white" ? logos.wordmarkStackedWhite : logos.wordmarkStackedJade,
  alt: "KUKU", style: { height: size, width: "auto", display: "block", ...style },
});
const masthead = (tone) => wordmark(tone, 32, { position: "absolute", top: SAFE, left: SAFE, zIndex: 2 });
const ornamentBR = (ground, kind) => h("img", {
  src: ornaments[pickOrnament(ground, kind)], alt: "",
  style: { position: "absolute", bottom: 56, right: -36, width: 140, height: "auto", pointerEvents: "none", zIndex: 2 },
});
const ornamentTR = (ground, kind) => h("img", {
  src: ornaments[pickOrnament(ground, kind)], alt: "",
  style: { position: "absolute", top: 40, right: -36, width: 140, height: "auto", pointerEvents: "none", zIndex: 2 },
});

/* ---------- 1 · STAMP — full-bleed photo + stacked wordmark in one corner ---------- */
export function FrameStamp({ photo, kind = "scene", tone = "white", corner = "tl" }) {
  const pos = { tl: { top: 56, left: 56 }, tr: { top: 56, right: 56 }, bl: { bottom: 56, left: 56 }, br: { bottom: 56, right: 56 } }[corner];
  return h("div", { style: frameBase(1080, 1080, J, C) },
    h("div", { style: { position: "absolute", inset: 0 } }, img(photo, kind)),
    stackedWordmark(tone, 96, { position: "absolute", zIndex: 2, ...pos }),
  );
}

/* ---------- 2 · PLATE — photo card + "Name · one-line subtext" on one baseline ---------- */
export function FramePlate({ photo, photoKind = "food", name, subtext, ground = "cream", ornament }) {
  const g = GROUND[ground] || GROUND.cream;
  const len = titleLen(name);
  const namePx = { short: 48, medium: 40, long: 32 }[len];
  return h("div", { style: { ...frameBase(1080, 1080, g.bg, g.fg), padding: `${MASTHEAD}px ${SAFE}px ${FOOTER}px`, display: "flex", flexDirection: "column", gap: 28 } },
    masthead(g.wm),
    ornamentBR(ground, ornament),
    h("div", { style: { position: "relative", width: "100%", flex: 1, minHeight: 0, borderRadius: 16, overflow: "hidden", boxShadow: `12px 12px 0 0 ${g.stamp}` } }, img(photo, photoKind)),
    h("p", { style: { margin: 0, flexShrink: 0, display: "flex", flexWrap: "wrap", alignItems: "baseline", columnGap: 18, rowGap: 4, maxWidth: "calc(100% - 180px)", textWrap: "balance" } },
      h("span", { style: { fontWeight: 700, fontSize: namePx, lineHeight: 1, letterSpacing: "-0.02em" } }, name),
      subtext && h("span", { style: { fontWeight: 500, fontSize: 22, lineHeight: 1, letterSpacing: "0.02em", opacity: 0.8, display: "inline-flex", alignItems: "baseline", gap: 18 } },
        h("span", { style: { fontWeight: 700, fontSize: 26, opacity: 0.5 } }, "·"), subtext),
    ),
  );
}

/* ---------- 3 · WINDOW — editorial: photo card + headline (+ body) ---------- */
export function FrameWindow({ photo, photoKind = "scene", title, body, ground = "cream", ornament }) {
  const g = GROUND[ground] || GROUND.cream;
  const len = titleLen(title);
  return h("div", { style: { ...frameBase(1080, 1080, g.bg, g.fg), padding: `${MASTHEAD}px ${SAFE}px ${FOOTER}px`, display: "flex", flexDirection: "column", gap: 24 } },
    masthead(g.wm),
    ornamentBR(ground, ornament),
    h("div", { style: { position: "relative", width: "100%", flex: 1, minHeight: 0, borderRadius: 16, overflow: "hidden", boxShadow: `16px 16px 0 0 ${g.stamp}` } }, img(photo, photoKind)),
    h("div", { style: { display: "flex", flexDirection: "column", gap: 12, flexShrink: 0, overflow: "hidden", maxWidth: "calc(100% - 180px)" } },
      h("h2", { style: { margin: 0, fontFamily: BODY, fontWeight: 700, fontSize: TITLE_PX[len], lineHeight: TITLE_LH[len], letterSpacing: "-0.02em", color: "inherit", textWrap: "balance" } }, title),
      body && h("p", { style: { margin: 0, fontSize: 22, lineHeight: 1.4, opacity: 0.88, maxWidth: 760 } }, body),
    ),
  );
}

/* ---------- 4 · STRIP — 1920×1080 banner: photo + color block (eyebrow, display title) ---------- */
export function FrameStrip({ photo, photoKind = "scene", eyebrow, title, side = "bottom", blockTone = "jade" }) {
  const g = GROUND[blockTone] || GROUND.jade;
  const len = titleLen(title);
  const grid = side === "bottom" ? { gridTemplateRows: "720px 360px" } : side === "top" ? { gridTemplateRows: "360px 720px" } : { gridTemplateColumns: "720px 1fr" };
  const titlePx = side === "left" ? { short: 84, medium: 68, long: 52 }[len] : { short: 96, medium: 80, long: 64 }[len];
  const photoEl = h("div", { style: { width: "100%", height: "100%", minHeight: 0, minWidth: 0 } }, img(photo, photoKind));
  const blockEl = h("div", { style: { position: "relative", padding: side === "left" ? 80 : "56px 80px", display: "flex", flexDirection: "column", justifyContent: "center", gap: 18, minWidth: 0, background: g.bg, color: g.fg } },
    eyebrow && h("span", { style: { alignSelf: "flex-start", background: blockTone === "mustard" ? J : M, color: blockTone === "mustard" ? M : J, fontWeight: 800, fontSize: 20, letterSpacing: "0.16em", textTransform: "uppercase", padding: "10px 22px", borderRadius: 999, whiteSpace: "nowrap" } }, eyebrow),
    h("h2", { style: { margin: 0, fontFamily: DISPLAY, fontSize: titlePx, lineHeight: 0.94, letterSpacing: "-0.02em", textTransform: "uppercase", color: "inherit", textWrap: "balance" } }, title),
    stackedWordmark(g.wm, 44, { position: "absolute", bottom: 28, right: 40 }),
  );
  const order = side === "top" ? [blockEl, photoEl] : side === "left" ? [blockEl, photoEl] : [photoEl, blockEl];
  return h("div", { style: { ...frameBase(1920, 1080, g.bg, g.fg), display: "grid", ...grid } }, ...order);
}

/* ---------- 5 · SHEET — six-cell contact sheet on cream ---------- */
export function FrameSheet({ photos = [], title, eyebrow, ornament }) {
  const len = titleLen(title);
  const titlePx = { short: 64, medium: 52, long: 40 }[len];
  return h("div", { style: { ...frameBase(1080, 1080, C, J), padding: `${MASTHEAD}px ${SAFE}px ${FOOTER}px`, display: "flex", flexDirection: "column" } },
    masthead("jade"),
    ornamentTR("cream", ornament),
    h("div", { style: { display: "flex", flexDirection: "column", gap: 14, marginBottom: 28 } },
      eyebrow && h("span", { style: { alignSelf: "flex-start", background: M, color: J, fontWeight: 800, fontSize: 20, letterSpacing: "0.16em", textTransform: "uppercase", padding: "10px 22px", borderRadius: 999, whiteSpace: "nowrap" } }, eyebrow),
      h("h2", { style: { margin: 0, fontFamily: BODY, fontWeight: 700, fontSize: titlePx, lineHeight: len === "long" ? 1.05 : 0.98, letterSpacing: "-0.02em", color: J, textWrap: "balance", maxWidth: 820 } }, title),
    ),
    h("div", { style: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gridAutoRows: "1fr", gap: 16, flex: 1, minHeight: 0 } },
      ...photos.slice(0, 6).map((p, i) => h("div", { key: i, style: { position: "relative", borderRadius: 14, overflow: "hidden", background: "rgba(23,72,45,0.06)" } },
        h("div", { style: { position: "absolute", inset: 0 } }, img(typeof p === "string" ? p : p.src, typeof p === "string" ? "food" : p.kind || "food")))),
    ),
  );
}
