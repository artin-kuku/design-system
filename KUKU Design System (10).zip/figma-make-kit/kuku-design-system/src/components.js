// KUKU Design System — React components (React 18, no build step required)
import React from "react";
import { logos, ornaments, pickOrnament } from "./assets.js";

const h = React.createElement;
const cx = (...a) => a.filter(Boolean).join(" ");

/* =====================================================================
   Typography
   ===================================================================== */

/** ONE per composition. Dela Gothic One, uppercase. Wrap a word in <em> for mustard. */
export function Display({ size = "1", as = "h1", className, children, ...rest }) {
  return h(as, { className: cx(`kk-display-${size}`, className), ...rest }, children);
}

/** Flat mustard pill above a headline. No shadow. */
export function Eyebrow({ onMustard = false, className, children, ...rest }) {
  return h("span", { className: cx("kk-eyebrow", onMustard && "kk-eyebrow--on-mustard", className), ...rest }, children);
}

/** Farsi/Persian script helper (Vazirmatn, RTL). */
export function Farsi({ as = "span", className, children, ...rest }) {
  return h(as, { className: cx("farsi", className), lang: "fa", dir: "rtl", ...rest }, children);
}

/* =====================================================================
   Controls
   ===================================================================== */

/** variant: primary | secondary | ghost | stamp   size: sm | md | lg */
export function Button({ variant = "primary", size = "md", as = "button", className, children, ...rest }) {
  return h(as, {
    className: cx("kk-btn", `kk-btn--${variant}`, size !== "md" && `kk-btn--${size}`, className),
    type: as === "button" ? (rest.type || "button") : undefined,
    ...rest,
  }, children);
}

/** tone: jade | mustard | guava | iso | outline */
export function Badge({ tone = "jade", className, children, ...rest }) {
  return h("span", { className: cx("kk-badge", `kk-badge--${tone}`, className), ...rest }, children);
}

/** Screen-printed mustard tag with hard jade offset. e.g. "FAMILY RECIPE" */
export function StampTag({ className, children, ...rest }) {
  return h("span", { className: cx("kk-stamp-tag", className), ...rest }, children);
}

/* =====================================================================
   Forms
   ===================================================================== */

export function Field({ label, help, error, className, children }) {
  return h("label", { className: cx("kk-field", className) },
    label && h("span", { className: "kk-label" }, label),
    children,
    error ? h("span", { className: "kk-error" }, error) : help ? h("span", { className: "kk-help" }, help) : null,
  );
}
export function Input({ error, filled, className, ...rest }) {
  return h("input", { className: cx("kk-input", filled && "kk-input--filled", error && "kk-input--error", className), ...rest });
}
export function Select({ className, children, ...rest }) {
  return h("select", { className: cx("kk-select", className), ...rest }, children);
}
export function Textarea({ className, ...rest }) {
  return h("textarea", { className: cx("kk-textarea", className), rows: 4, ...rest });
}

/* =====================================================================
   Surfaces
   ===================================================================== */

/** tone: white | jade | mustard */
export function Card({ tone = "white", className, children, ...rest }) {
  return h("div", { className: cx("kk-card", tone !== "white" && `kk-card--${tone}`, className), ...rest }, children);
}

/** Menu card: 84px photo thumb, title, one-line description, price (menu contexts ONLY — never on social). */
export function MenuCard({ image, title, description, price, className, ...rest }) {
  return h("div", { className: cx("kk-menu-card", className), ...rest },
    h("div", { className: "kk-menu-card__thumb" }, image && h("img", { src: image, alt: "" })),
    h("div", { className: "kk-menu-card__body" },
      h("h4", { className: "kk-menu-card__title" }, title),
      description && h("p", { className: "kk-menu-card__desc" }, description),
    ),
    price != null && h("div", { className: "kk-menu-card__price" }, price),
  );
}

/* =====================================================================
   Brand marks & decoration
   ===================================================================== */

/** variant: lockup | lockup-white | lockup-alt | stacked | horizontal   tone (for wordmarks): jade | white */
export function Logo({ variant = "lockup", tone = "jade", height = 48, className, ...rest }) {
  const map = {
    "lockup": logos.lockup,
    "lockup-white": logos.lockupWhite,
    "lockup-alt": logos.lockupAlt,
    "stacked": tone === "white" ? logos.wordmarkStackedWhite : logos.wordmarkStackedJade,
    "horizontal": tone === "white" ? logos.wordmarkHorizontalWhite : logos.wordmarkHorizontalJade,
  };
  return h("img", { src: map[variant] || logos.lockup, alt: "KUKU", style: { height, width: "auto", display: "block" }, className, ...rest });
}

/**
 * The ONE approved ornament treatment: a single ornament pinned to a corner,
 * partially bled off the right edge (~140px), no rotation, native colors.
 * Parent needs position:relative + overflow:hidden (or use className "kk-ornament-anchor").
 * ground picks a color-safe ornament automatically (never mustard-on-mustard).
 */
export function Ornament({ ground = "cream", kind, corner = "tr", className, ...rest }) {
  const k = pickOrnament(ground, kind);
  return h("img", { src: ornaments[k], alt: "", className: cx("kk-ornament", `kk-ornament--${corner}`, className), ...rest });
}

/** Face-safe photo. kind: portrait | food | scene */
export function Photo({ src, kind = "scene", alt = "", className, ...rest }) {
  return h("img", { src, alt, className: cx("kk-photo", `kk-photo--${kind}`, className), ...rest });
}
