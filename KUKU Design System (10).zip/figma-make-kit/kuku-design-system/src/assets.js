// KUKU Design System — asset registry
// Every brand asset, addressable by name. Drop the URL into <img src>.
//
// Base path resolution (no import.meta, so this file also compiles as a classic script):
//   1. window.KUKU_ASSET_BASE if set (e.g. a CDN or "/node_modules/@kuku/design-system/assets/")
//   2. otherwise the folder of the currently executing <script> + "../assets/"
//   3. otherwise a package-relative "./assets/" (Vite/webpack rewrite this via the exports map)
function resolveBase() {
  if (typeof window !== "undefined" && window.KUKU_ASSET_BASE) return String(window.KUKU_ASSET_BASE);
  if (typeof document !== "undefined" && document.currentScript && document.currentScript.src) {
    try { return new URL("../assets/", document.currentScript.src).href; } catch (e) { /* fall through */ }
  }
  return "./assets/";
}
const base = resolveBase();
export const assetUrl = (file) => (base.endsWith("/") ? base : base + "/") + file;

/* ---- Logos & wordmarks (always place the file — never typeset "KUKU") ---- */
export const logos = {
  lockup:            assetUrl("logo-lockup.svg"),          // mascot + wordmark, jade — DEFAULT
  lockupWhite:       assetUrl("logo-lockup-white.svg"),    // white, for jade grounds
  lockupAlt:         assetUrl("logo-lockup-alt.svg"),      // alt mascot pose
  lockupJadePng:     assetUrl("logo-lockup-jade.png"),
  wordmarkStackedJade:  assetUrl("wordmark-stacked-jade.png"),   // transparent bg
  wordmarkStackedWhite: assetUrl("wordmark-stacked-white.png"),  // transparent bg
  wordmarkHorizontalJade:  assetUrl("wordmark-horizontal-jade.png"),
  wordmarkHorizontalWhite: assetUrl("wordmark-horizontal-white.png"),
  wordmarkHorizontalSvg:      assetUrl("wordmark-horizontal.svg"),
  wordmarkHorizontalWhiteSvg: assetUrl("wordmark-horizontal-white.svg"),
};

/* ---- Mascot poses (PNG only) ---- */
export const mascots = {
  main:      assetUrl("mascot-main.png"),
  thumbsup:  assetUrl("mascot-thumbsup.png"),
  eating:    assetUrl("mascot-eating.png"),
  drinking:  assetUrl("mascot-drinking.png"),
  utensils:  assetUrl("mascot-utensils.png"),
  lockupOnly: assetUrl("mascot-lockup-only.png"),
  white1:    assetUrl("mascot-white-01.png"),
  white2:    assetUrl("mascot-white-02.png"),
  white3:    assetUrl("mascot-white-03.png"),
  white4:    assetUrl("mascot-white-04.png"),
};

/* ---- Approved ornaments for compositions (the three used by the frame system) ---- */
export const ornaments = {
  "flower-1":    assetUrl("ornament-flower-coral-mustard.png"), // coral + mustard rosette
  "tulip-mixed": assetUrl("ornament-tulip-mixed.png"),          // coral + green + mustard tulip
  rose:          assetUrl("icon-rose-mixed.png"),               // coral + mustard + green rose
};

/* ---- Full ornament icon library (decorative, color-locked; NOT UI icons) ---- */
export const icons = {
  paisleyJade:     assetUrl("icon-paisley-jade.png"),
  paisleyMustard:  assetUrl("icon-paisley-mustard.png"),
  tulipMustard:    assetUrl("icon-tulip-mustard.png"),
  tulipStem:       assetUrl("icon-tulip-stem.png"),
  flowerCoral:     assetUrl("icon-flower-coral.png"),
  flowerCoralAlt:  assetUrl("icon-flower-coral-alt.png"),
  roseMixed:       assetUrl("icon-rose-mixed.png"),
  flowerCoralMustard: assetUrl("ornament-flower-coral-mustard.png"),
  flowerMustardCoral: assetUrl("ornament-flower-mustard-coral.png"),
  tulipMixed:      assetUrl("ornament-tulip-mixed.png"),
  png: ["03","04","06","08","09","11","12","13","15","16","18"].reduce((m, n) => (m[`icon${n}`] = assetUrl(`icon-${n}.png`), m), {}),
  svg: ["09","10","11","12","13","14","15","16","17"].reduce((m, n) => (m[`icon${n}`] = assetUrl(`icons/icon-${n}.svg`), m), {}),
};

/* ---- Stickers / badges ---- */
export const stickers = {
  bird:             assetUrl("sticker-bird.png"),
  birdFlying:       assetUrl("sticker-bird-flying.png"),
  cartoucheKuku:    assetUrl("sticker-cartouche-kuku.png"),
  cartoucheMustard: assetUrl("sticker-cartouche-mustard.png"),
  flowerMustardCoral: assetUrl("sticker-flower-mustard-coral.png"),
  haveYouGoneKuku:  assetUrl("sticker-have-you-gone-kuku.png"),
  herbSpice:        assetUrl("sticker-herb-spice.png"),
  herbSpiceAlt:     assetUrl("sticker-herb-spice-alt.png"),
  mascot:           assetUrl("sticker-mascot.png"),
  tulipCoral:       assetUrl("sticker-tulip-coral.png"),
  svg: [1,2,3,4,5,6,7,8,9].reduce((m, n) => (m[`sticker${n}`] = assetUrl(`stickers/sticker-${n}.svg`), m), {}),
};

/* ---- Cartouche mask shapes (white-on-transparent PNG, use as CSS mask-image) ---- */
export const shapes = {
  boteh:      assetUrl("shapes/boteh.png"),
  mihrab:     assetUrl("shapes/mihrab.png"),
  quatrefoil: assetUrl("shapes/quatrefoil.png"),
  rosette:    assetUrl("shapes/rosette.png"),
};

/* ---- Production templates (SVG dielines) ---- */
export const production = {
  standingSignage: assetUrl("standing-signage.svg"),
  packagingSleeve: assetUrl("packaging-sleeve.svg"),
};

/* ---- Photography (real KUKU food / team shots) ---- */
export const photos = {
  chefSamovar:      { src: assetUrl("photos/chef-samovar.jpg"),       kind: "scene" },
  dishAdasi:        { src: assetUrl("photos/dish-adasi.jpg"),         kind: "food" },
  dishBeefBowl:     { src: assetUrl("photos/dish-beef-bowl.jpg"),     kind: "food" },
  dishBeefWrap:     { src: assetUrl("photos/dish-beef-wrap.jpg"),     kind: "food" },
  dishChai:         { src: assetUrl("photos/dish-chai.jpg"),          kind: "food" },
  dishChickenWrap:  { src: assetUrl("photos/dish-chicken-wrap.jpg"),  kind: "food" },
  dishMahicheh:     { src: assetUrl("photos/dish-mahicheh.jpg"),      kind: "food" },
  dishMastOKhiar:   { src: assetUrl("photos/dish-mast-o-khiar.jpg"),  kind: "food" },
  dishSholehZard:   { src: assetUrl("photos/dish-sholeh-zard.jpg"),   kind: "food" },
  dishSpread:       { src: assetUrl("photos/dish-spread.jpg"),        kind: "scene" },
  dishTahchinAlt:   { src: assetUrl("photos/dish-tahchin-alt.jpg"),   kind: "food" },
  dishTahchinChicken: { src: assetUrl("photos/dish-tahchin-chicken.jpg"), kind: "food" },
  fesenjan:         { src: assetUrl("photos/fesenjan.jpg"),           kind: "food" },
  mahichehTulips:   { src: assetUrl("photos/mahicheh-tulips.jpg"),    kind: "food" },
  ownersPortrait:   { src: assetUrl("photos/owners-portrait.jpg"),    kind: "portrait" },
  spreadMahicheh:   { src: assetUrl("photos/spread-mahicheh.jpg"),    kind: "scene" },
  tahchinCloseup:   { src: assetUrl("photos/tahchin-closeup.jpg"),    kind: "food" },
  tahchinPlatter:   { src: assetUrl("photos/tahchin-platter.jpg"),    kind: "food" },
  teamClapping:     { src: assetUrl("photos/team-clapping.jpg"),      kind: "scene" },
  teamPasshole:     { src: assetUrl("photos/team-passhole.jpg"),      kind: "scene" },
};

/* ---- Ornament ↔ ground pairing matrix (never mustard-on-mustard / green-on-jade) ---- */
export const ORNAMENT_RULES = {
  cream:   { allowed: ["flower-1", "tulip-mixed", "rose"], fallback: "flower-1" },
  white:   { allowed: ["flower-1", "tulip-mixed", "rose"], fallback: "flower-1" },
  jade:    { allowed: ["flower-1"],                        fallback: "flower-1" },
  mustard: { allowed: ["tulip-mixed", "rose"],             fallback: "tulip-mixed" },
};
export function pickOrnament(ground = "cream", requested) {
  const rule = ORNAMENT_RULES[ground] || ORNAMENT_RULES.cream;
  if (requested && rule.allowed.includes(requested)) return requested;
  return rule.fallback;
}
