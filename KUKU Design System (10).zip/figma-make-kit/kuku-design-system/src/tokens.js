// KUKU Design System — tokens as a JS object (mirrors tokens.css)
export const tokens = {
  color: {
    jade: "#17482D", jadeDeep: "#0F3220", jadeSoft: "#2A6A45",
    mustard: "#E9AB0F", mustardDim: "#C7900A",
    guava: "#CD5647", guavaDeep: "#B0432F",
    isabelline: "#DDD3D2", isabellineWarm: "#EFE6E4",
    cream: "#F7F1EA", white: "#FFFFFF", ink: "#0F2A1B", muted: "#4A5A4F",
    borderDefault: "rgba(23, 72, 45, 0.18)",
  },
  ratio: { jade: 0.5, mustard: 0.3, negative: 0.2, guavaMax: 0.1 },
  font: {
    display: '"Dela Gothic One", "Ygro Sans", system-ui, sans-serif',
    body: '"Ygro Sans", "Inter", "Manrope", system-ui, sans-serif',
    farsi: '"Vazirmatn", "Ygro Sans", system-ui, sans-serif',
  },
  fontSize: {
    displayHero: "clamp(56px, 9vw, 132px)", display1: "clamp(44px, 6vw, 88px)", display2: "clamp(36px, 5vw, 64px)",
    h1: 48, h2: 36, h3: 26, h4: 20, bodyLg: 18, body: 16, bodySm: 14, caption: 12,
  },
  space: { 1: 4, 2: 8, 3: 12, 4: 16, 5: 24, 6: 32, 7: 48, 8: 64, 9: 96, 10: 128 },
  radius: { xs: 4, sm: 8, md: 14, lg: 22, pill: 999, input: 10, thumb: 16 },
  shadow: {
    sm: "0 1px 2px rgba(15, 42, 27, 0.08)",
    md: "0 6px 14px -4px rgba(15, 42, 27, 0.18)",
    lg: "0 18px 40px -12px rgba(15, 42, 27, 0.28)",
    stamp: "4px 4px 0 0 #17482D",
    stampMustard: "4px 4px 0 0 #E9AB0F",
    stampMd: "12px 12px 0 0 #E9AB0F",
    stampLg: "16px 16px 0 0 #E9AB0F",
  },
  motion: {
    easeOut: "cubic-bezier(0.22, 0.7, 0.25, 1)", easeBounce: "cubic-bezier(0.34, 1.56, 0.64, 1)",
    fast: 140, base: 220, slow: 420,
  },
  frame: { safe: 64, masthead: 128, footer: 112, ornamentWidth: 140, ornamentBleed: -36 },
};
export default tokens;
