# @kuku/design-system

Brand tokens, fonts, assets, and React 18 components for **KUKU — Persian Counter & Grill**.
Built for Figma Make kits and production Vite/React apps. No build step — plain ESM.

```bash
npm i @kuku/design-system
```

```js
import "@kuku/design-system/styles.css";
import { Button, MenuCard, Logo, Ornament, FrameWindow, photos } from "@kuku/design-system";

<Logo variant="horizontal" height={32} />
<Button variant="stamp">Go KUKU →</Button>
<FrameWindow photo={photos.chefSamovar.src} photoKind="scene" ground="cream"
  title="Brewed strong, poured slow." body="Chai service runs all day from a copper samovar." />
```

## What's inside

| Path | Contents |
| --- | --- |
| `src/tokens.css` | All CSS custom properties (colors, type, spacing, radii, shadows, motion, frame layout) |
| `src/fonts.css` | `@font-face` for Dela Gothic One + Ygro Sans (Book/Medium/Bold); Vazirmatn via Google Fonts |
| `src/styles.css` | fonts + tokens + element defaults + `kk-*` component classes |
| `src/components.js` | `Display Eyebrow Farsi Button Badge StampTag Field Input Select Textarea Card MenuCard Logo Ornament Photo` |
| `src/frames.js` | Social frames `FrameStamp FramePlate FrameWindow FrameStrip FrameSheet` + `titleLen()` |
| `src/assets.js` | URL registry: `logos mascots ornaments icons stickers shapes production photos` + `pickOrnament()` |
| `src/tokens.js` | Tokens as a JS object |
| `tokens/tokens.json` | W3C DTCG token file (import into Figma Variables via Tokens Studio / Variables Import) |
| `assets/` | 99 brand files — logos, wordmarks, mascots, 18 ornaments (PNG+SVG), 9 stickers (PNG+SVG), 4 cartouche masks, 2 print dielines, 20 photos |
| `fonts/` | 4 `.ttf` files |
| `GUIDELINES.md` | The Make-kit guidelines document |

## Exports

```js
import "@kuku/design-system/styles.css";   // everything
import "@kuku/design-system/tokens.css";   // tokens only
import "@kuku/design-system/fonts.css";    // fonts only
import tokens from "@kuku/design-system/tokens.json";
import lockup from "@kuku/design-system/assets/logo-lockup.svg";
```

## Font licensing

Ygro Sans Beta and Dela Gothic One `.ttf` files are bundled. Dela Gothic One is OFL. Confirm your Ygro Sans license permits redistribution before publishing this package **publicly**; otherwise publish to a private registry (see `PUBLISH.md`).
