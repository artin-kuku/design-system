# KUKU asset inventory — paste this into Figma Make (Route C)

Build with these exact paths as placeholders; the real files will be dropped in later under `/assets/…` and `/fonts/…`. Full rules are in `GUIDELINES.md`.

## Colors (hex)
jade #17482D (dominant ~50%) · jade-deep #0F3220 · jade-soft #2A6A45 · mustard #E9AB0F (accent ~30%) · mustard-dim #C7900A · guava #CD5647 (tertiary ≤10%, never a background) · guava-deep #B0432F · isabelline #DDD3D2 · isabelline-warm #EFE6E4 · cream #F7F1EA (page surface) · white #FFFFFF (cards) · ink #0F2A1B (text) · muted #4A5A4F

## Fonts (`/fonts/`)
- `DelaGothicOne-Regular.ttf` — display, uppercase-only, ONE headline per composition
- `YgroSansBeta-Book.ttf` (400) · `YgroSansBeta-Medium.ttf` (500) · `YgroSansBeta-Bold.ttf` (700) — all headings, body, UI
- Vazirmatn (Google Fonts) — Farsi script, RTL

## Logos & wordmarks (`/assets/`) — always place the file, never typeset "KUKU"
- `logo-lockup.svg` — mascot + wordmark, jade. DEFAULT.
- `logo-lockup-white.svg` — white version for jade grounds
- `logo-lockup-alt.svg` — alt mascot pose
- `logo-lockup-jade.png`, `logo-lockup-blank.png` — raster fallbacks
- `wordmark-stacked-jade.png`, `wordmark-stacked-white.png` — transparent stacked wordmark (use when mascot is already in layout)
- `wordmark-horizontal-jade.png`, `wordmark-horizontal-white.png` — horizontal wordmark (footers, mastheads, social top-left)
- `wordmark-horizontal.svg`, `wordmark-horizontal-white.svg`, `wordmark-stacked.svg`, `wordmark-stacked-white.svg`, `wordmark-stacked.png` — SVG/alt versions (stacked SVGs carry a filled background)

## Mascot poses (`/assets/`, PNG, transparent) — one per composition, corner-anchored, never recolored
- `mascot-main.png` · `mascot-thumbsup.png` · `mascot-eating.png` · `mascot-drinking.png` · `mascot-utensils.png` · `mascot-lockup-only.png` (jade line art)
- `mascot-white-01.png` … `mascot-white-04.png` (white, for jade grounds)
- `sticker-mascot.png` (badge version)

## Ornaments (`/assets/`) — decorative only, NOT UI icons; 0° rotation, full opacity, native colors
Approved for compositions (one per layout, 140px, top-right or bottom-right, bled 36px off the right edge):
- `ornament-flower-coral-mustard.png` — coral+mustard rosette → cream, white, or jade grounds
- `ornament-tulip-mixed.png` — coral+green+mustard tulip → cream or mustard grounds
- `icon-rose-mixed.png` — coral+mustard+green rose → cream or mustard grounds
Full library: `icon-paisley-jade.png`, `icon-paisley-mustard.png`, `icon-tulip-mustard.png`, `icon-tulip-stem.png`, `icon-flower-coral.png`, `icon-flower-coral-alt.png`, `ornament-flower-mustard-coral.png`, `icon-03/04/06/08/09/11/12/13/15/16/18.png`, and vectors `icons/icon-09.svg` … `icons/icon-17.svg`.
Rule: never mustard ornaments on mustard grounds; never green-heavy ornaments on jade.

## Stickers & badges (`/assets/`) — screen-print feel, 4px hard jade offset shadow style
- `sticker-have-you-gone-kuku.png` — tagline sticker
- `sticker-cartouche-kuku.png`, `sticker-cartouche-mustard.png` — ornate Persian frames (do NOT fake with border-radius)
- `sticker-herb-spice.png`, `sticker-herb-spice-alt.png` — "Herb, spice & everything nice"
- `sticker-bird.png`, `sticker-bird-flying.png` — bird motif (clear-space unit for the logo)
- `sticker-flower-mustard-coral.png`, `sticker-tulip-coral.png`
- Vectors: `stickers/sticker-1.svg` … `stickers/sticker-9.svg`

## Cartouche masks (`/assets/shapes/`, white-on-transparent PNG → CSS `mask-image`)
`boteh.png` · `mihrab.png` · `quatrefoil.png` · `rosette.png`

## Print dielines (`/assets/`)
`standing-signage.svg` (A-frame) · `packaging-sleeve.svg` (wrap)

## Photos (`/assets/photos/`, JPG, 1600px) — real KUKU shots
People/portrait (crop with object-position: center 28%): `owners-portrait.jpg`
Scenes: `chef-samovar.jpg` · `team-clapping.jpg` · `team-passhole.jpg` · `dish-spread.jpg` · `spread-mahicheh.jpg`
Food: `fesenjan.jpg` · `dish-tahchin-chicken.jpg` · `dish-tahchin-alt.jpg` · `tahchin-closeup.jpg` · `tahchin-platter.jpg` · `dish-mahicheh.jpg` · `mahicheh-tulips.jpg` · `dish-adasi.jpg` · `dish-beef-bowl.jpg` · `dish-beef-wrap.jpg` · `dish-chicken-wrap.jpg` · `dish-mast-o-khiar.jpg` · `dish-sholeh-zard.jpg` · `dish-chai.jpg`

## Code (`/src/`)
`tokens.css` (all CSS variables) · `fonts.css` (@font-face) · `styles.css` (element defaults + `kk-*` component classes) · `components.js` (Button, Badge, StampTag, Eyebrow, Display, Farsi, Card, MenuCard, Field/Input/Select/Textarea, Logo, Ornament, Photo) · `frames.js` (social frames: Stamp, Plate, Window, Strip, Sheet) · `assets.js` (asset registry + ornament pairing rules) · `tokens/tokens.json` (W3C tokens)
