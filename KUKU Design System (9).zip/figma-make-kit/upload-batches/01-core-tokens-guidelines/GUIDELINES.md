# KUKU Design System — Guidelines for Figma Make

> Paste this file into the **Guidelines** section of the Make kit. It tells Make how to use `@kuku/design-system`.

## Who KUKU is

KUKU — Persian Counter & Grill, 318 N. La Brea Ave, Inglewood, CA. Fast-casual Persian food cooked by the Esfahani family. The brand reframes 16th-century Persian heritage as **playful, friendly, witty, and authentic** — heritage made approachable, never gatekept.

- **Positioning:** Casually witty Persian food for everyone.
- **Guardrail:** the cultural angle is counter-narrative, never political. Talk about food, family, humor, diaspora life. **Never** current Iranian politics or geopolitics.

## Setup (always do this first)

```js
import "@kuku/design-system/styles.css"; // fonts + tokens + component classes
import { Button, Badge, StampTag, Eyebrow, Display, Farsi, Card, MenuCard,
         Field, Input, Select, Textarea, Logo, Ornament, Photo,
         FrameStamp, FramePlate, FrameWindow, FrameStrip, FrameSheet,
         logos, mascots, ornaments, stickers, photos, shapes, tokens } from "@kuku/design-system";
```

Set the page background to `var(--color-cream)` (`#F7F1EA`). Pure white is for cards only.

## Color — the 50 / 30 / 20 rule

- **Jade `#17482D`** is the dominant color, ~50% of any composition. It IS the brand.
- **Mustard `#E9AB0F`** is the accent, ~30% — CTAs, callouts, eyebrows, ornaments, stamp shadows.
- **Cream/white** is ~20% negative space.
- **Guava `#CD5647`** is tertiary only (5–10%): spicy badges, one accent word. Never a primary background.
- **Isabelline `#DDD3D2`** is a soft neutral for disabled states and quiet fills.

**Approved pairings:** jade-on-white (default), white-on-jade (high-contrast secondary), jade-on-mustard (CTA/accent block).
**Never:** mustard-on-guava (vibrates), jade-on-guava (low contrast), mustard ornaments on mustard grounds, green-heavy ornaments on jade grounds.

Use **two-color blocking** — split layouts 50/50 jade+mustard or jade+white. No four-color confetti. **No gradients. No noise/grain. No frosted glass / backdrop-filter.** Flat color; photography is the only place tonal range lives.

## Typography

Three families, imported by `styles.css`:

- **Dela Gothic One** (`var(--font-display)`) — display face. Uppercase-only, loud. **Use exactly ONCE per composition** for the hero headline via `<Display size="hero|1|2">`. Wrap one word in `<em>` to turn it mustard. Never stack two display headlines.
- **Ygro Sans** (`var(--font-body)`) — everything else. Book 400 / Medium 500 / Bold 700. H1–H4 are Ygro Sans Bold, jade, `letter-spacing:-0.01em`, `line-height:1.1`. Body is 16px / 1.5.
- **Vazirmatn** (`var(--font-farsi)`) — Farsi script, RTL. Pair English + Farsi when culturally meaningful, e.g. *No Ta'arof / بی‌تعارف*. Use `<Farsi>`.

Scale: display-hero 132 · display-1 88 · display-2 64 · h1 48 · h2 36 · h3 26 · h4 20 · body-lg 18 · body 16 · body-sm 14 · caption 12.

**The KUKU wordmark is a custom logotype.** Always place `<Logo>` — never typeset "KUKU" in Dela Gothic.

**Length-aware headlines (social frames):** ≤4 words → 72px · 5–7 words → 56px · ≥8 words → 40px. Headlines must never clip or overlap a logo or ornament.

## Voice & copy

Playful · Friendly · Witty · Authentic. Write the way the Esfahani family talks at the counter.

- Casual, real-people talk with a bit of wit: *"We're KUKIN' up something good."*
- Light-hearted and inviting: *"Have you gone KUKU today?"*
- Simple, trustworthy, direct. No jargon. No "artisanal / curated / culinary experience."
- Wit guides, never lectures. A pun lands once, then get out of the way.
- First person plural ("we", "our kitchen"); reader is "you".
- Display headlines ALL CAPS (the font is uppercase-only). Body sentence case. Buttons Title Case ("Order Pickup", "See the Menu").
- Em dashes welcome. Exclamation points sparingly.
- **Emoji: never in product UI, menus, or print.** Sparingly on organic social only.
- **Never show prices on social posts.** Prices belong on menus (`<MenuCard price>`) and menu PDFs only.

Taglines to drop in: "Have you gone KUKU today?" · "Herb, spice & everything nice" · "We're KUKIN' up something good" · "Authentic Persian Taste" · "Persian Made [easy / fresh / delicious]".

## Components

### Button — `<Button variant size>`
- `primary` — jade fill, white text. Default CTA. Hover → jade-soft. Press → jade-deep, content shifts down 1px (no scale).
- `secondary` — mustard fill, jade text.
- `ghost` — transparent, 1.5px jade border.
- `stamp` — mustard fill + 4px hard jade offset shadow (`--shadow-stamp`). Use for the one loud CTA ("Go KUKU →").
- `disabled` — isabelline fill, muted text.
- Pill radius (999px), Ygro Sans Bold 14px, 12×22 padding. Sizes `sm|md|lg`.
- One display headline → one paragraph → one CTA. **No more.**

### Badge — `<Badge tone>` · `jade | mustard | guava | iso | outline`
Uppercase 12px Ygro Bold, 0.06em tracking, pill. e.g. New / Catering / Spicy / Vegan / Gluten Free.

### StampTag — `<StampTag>`
Screen-printed mustard tag, 6px radius, 3px hard jade offset. e.g. FAMILY RECIPE.

### Eyebrow — `<Eyebrow>`
Flat mustard pill above a headline (20px, 800 weight, 0.16em). **No shadow on pills — hard shadows are for rectangles only.** On mustard grounds use `onMustard` (inverts to jade).

### Card — `<Card tone="white|jade|mustard">`
22px radius, `--shadow-sm` at rest → `--shadow-md` on hover. No rotation, no scale. White card on cream page needs no border. Optional single ornament at a corner (0° rotation).

### MenuCard — `<MenuCard image title description price>`
White, 22px radius, 84px photo thumb (16px radius), Ygro Bold 16 title, 13px muted description, price right-aligned. **Menus only.**

### Forms — `<Field label help error>` + `<Input>` / `<Select>` / `<Textarea>`
1.5px `--border-default` border, 10px radius, white fill, jade text, 14px. Focus: jade border + 3px `rgba(23,72,45,0.15)` halo. Labels 11px uppercase jade. Error: guava border.

### Logo — `<Logo variant tone height>`
Preference order: `lockup` (mascot + wordmark, default) → `stacked` → `horizontal` (footers, narrow bands, social mastheads). `tone="white"` on jade. Clear space = width of the bird element. Minimum 90px digital.

### Ornament — `<Ornament ground corner kind>`
**The one approved ornament treatment:** a single ornament, top-right or bottom-right corner, partially bled off the right edge, 140px wide, 0° rotation, native colors, full opacity. `ground` auto-picks a color-safe ornament (`flower-1` on cream/jade, `tulip-mixed` or `rose` on mustard). Parent must be `position:relative; overflow:hidden`.
- Never recolor with CSS filters, never rotate >5°, never reduce opacity, never cluster three ornaments, never crop or distort.
- Ornaments are decorative. **They are not UI icons.** For functional icons (cart, search, chevron) use Lucide at 1.5px stroke in jade — and flag that as a substitution.

### Photo — `<Photo src kind>`
`kind="portrait"` anchors `object-position: center 28%` so faces survive crops. `food`/`scene` center. Photos live in `photos.*` (20 real KUKU shots with `kind` pre-tagged). Photography vibe: casual, authentic, natural light, hands in frame, simple ceramics. No sterile stock, no fine-dining moodiness, no AI food.

## Social frames (1080×1080 / 1920×1080) — `Frame*`

Five named frames; pick by surface. All enforce: 64px text-safe inset, 128px top masthead reserve (horizontal wordmark TL), 112px bottom reserve, one ornament BR (TR on Sheet), face-safe crops, length-aware titles, **no prices, no eyebrow pills on Plate/Window**.

1. **`FrameStamp`** — full-bleed photo + stacked wordmark in one corner. Pure editorial, no copy.
2. **`FramePlate`** — photo card with 12px mustard stamp shadow; caption on ONE baseline: `Tāhchīn · Saffron-crusted chicken & rice cake`.
3. **`FrameWindow`** — photo card (16px stamp) + headline (+ optional one-line body). Photo flexes to fill; copy hugs the photo.
4. **`FrameStrip`** — 1920×1080 banner: photo + jade/mustard block with eyebrow + Dela Gothic title. `side="bottom|top|left"`.
5. **`FrameSheet`** — cream contact sheet: eyebrow + title + six 3×2 photo cells.

Grounds: `cream | jade | mustard`. Stamp shadow is mustard on cream/jade, jade on mustard.

## Layout

- 12-column grid on web. Generous white (or isabelline) space. KUKU never feels cluttered.
- Cartouche shapes (`shapes.*` masks, `stickers.cartouche*`) may break the grid — let one hang into a margin. Don't fake a cartouche with `border-radius`.
- Borders: none, or 1.5px solid jade. No hairline gray dividers — use cream-vs-white surface contrast.
- Shadows: soft elevation (`sm/md/lg`) for cards and floating UI; hard-edge stamp for stickers, badges, CTAs. No inner shadows, no neumorphism.
- Radii: cards 14/22px, primary CTAs pill, secondary 14px, inputs 10px.
- Transparency: only a 60% jade overlay on hero photography to lift white type, or a cream-to-transparent protection band behind text on a photo.

## Motion

Restrained — a restaurant, not SaaS. Default 220ms `--ease-out` fades + 4–8px slide-ins. `--ease-bounce` is reserved for the mascot entering frame. **No parallax, no scroll-triggered theatrics.** Hover never scales; press offsets 1px down.

## Mascot

Poses in `mascots.*` (main, thumbsup, eating, drinking, utensils; white1–4 for dark grounds). The mascot is itself an ornament: one per composition, anchored to a corner or edge, never tiled, never recolored. Vector mascot exists only inside `logos.lockup*` SVGs.

## Do / Don't (quick check before shipping)

**Do:** jade dominant · one Dela Gothic headline · Ygro Sans body · place the real logo file · one bled ornament · cream page, white cards · pill CTAs · flat color.
**Don't:** two display headlines · typeset "KUKU" · gradients/grain/glass · recolored or rotated ornaments · emoji in UI · prices on social · guava backgrounds · mustard-on-guava · political commentary · text under a logo or ornament.
