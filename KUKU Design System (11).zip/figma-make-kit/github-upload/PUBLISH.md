# Publish → Figma Make: step by step

## 0. One-time prep (5 min)

1. Install Node 18+ (`node -v`).
2. Create an npm account at npmjs.com if you don't have one. In a terminal: `npm login`.
3. Pick a package name. `@kuku/design-system` needs an npm **org** called `kuku` (free for public packages: npmjs.com → Add Organization). If the name is taken, edit `"name"` in `package.json` to e.g. `@your-handle/kuku-design-system` — every import path in `GUIDELINES.md` must match, so find-and-replace there too.

## 1. Publish

```bash
cd kuku-design-system
npm publish --access public
```

Bump `"version"` in `package.json` (1.0.1, 1.1.0 …) before every re-publish.

**Private instead?** Figma Make supports private packages on Organization/Enterprise plans via the org's private npm registry — an org admin sets up the scope. Follow Figma's "Bring your design system package to a Make kit" doc for the registry URL and token, then `npm publish` with that registry configured. Use private if the Ygro Sans font license doesn't allow public redistribution.

## 2. Create the Make kit

1. In Figma Make → **Design system context** (the screen from your screenshot) → **npm packages**.
2. Search for your package name and add it. Make installs it into the kit.
3. Open the kit's **Guidelines** tab → paste the full contents of `GUIDELINES.md`. (Make can auto-generate guidelines from the package; paste ours instead — it's the higher-fidelity version.)
4. Save → **Publish kit** to your team.

## 3. (Optional) Add Figma library styles for tokens

If you also want the tokens as Figma Variables (so Make's design panel shows them):

1. Open a new Figma Design file → run the **Tokens Studio** plugin (or Figma's native Variables import) → import `tokens/tokens.json`.
2. Publish that file as a team library.
3. Back in the Make kit → **Add items to your kit** → **Library styles** → pick the library.

## 4. Test the kit

Start a Make file, add the kit, and prompt:

> Build a KUKU catering landing page with a hero, a menu grid of 6 dishes, and a catering request form.

Check for: cream page · jade dominant · one Dela Gothic headline · Ygro Sans body · real logo file (not typed) · one bled ornament · no gradients · no emoji · prices only on menu cards. Anything off → tighten the relevant line in `GUIDELINES.md`, re-paste, re-test.

## Updating later

Edit source → bump version → `npm publish` → in the Make kit, update the package version → re-publish the kit.
