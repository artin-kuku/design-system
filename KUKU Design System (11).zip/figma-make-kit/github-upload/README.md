# KUKU Design System

Brand tokens, fonts, assets, and React 18 components for **KUKU — Persian Counter & Grill** (Inglewood, CA).
Built for Figma Make kits and production Vite/React apps.

- `GUIDELINES.md` — the rulebook (paste into a Figma Make kit's Guidelines)
- `ASSET-URLS.md` — raw URLs for every file (paste into Figma Make chat)
- `src/` — `tokens.css`, `fonts.css`, `styles.css`, React components (`components.js`, `frames.js`), asset registry (`assets.js`)
- `tokens/tokens.json` — W3C design tokens (import into Figma Variables)
- `assets/` — logos, wordmarks, mascots, ornaments, stickers, cartouche masks, print dielines, photos (screen-res)
- `fonts/` — Dela Gothic One, Ygro Sans Book/Medium/Bold
- `PUBLISH.md` — how to publish to npm for a reusable Make kit

```js
import "@kuku/design-system/styles.css";
import { Button, Logo, Ornament, FrameWindow, photos } from "@kuku/design-system";
```
